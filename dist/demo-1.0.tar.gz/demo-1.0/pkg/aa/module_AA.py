print("AA")

def fun_AA():
    print("in fun_AA")